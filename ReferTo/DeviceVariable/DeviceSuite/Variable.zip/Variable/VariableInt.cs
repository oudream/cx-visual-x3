﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CxDeviceSuite
{
    // 整数类型的变量
    public class VariableInt : VariableBase
    {
        public int Value { get; private set; }
        protected override Type GetValueType() => typeof(int);
        public override object GetValueObject() => Value;

        public override void UpdateValue(object newValue)
        {
            if (newValue is int intValue)
            {
                Value = intValue;
                RecordChange(); // 记录变化时间
            }
        }
    }


}
