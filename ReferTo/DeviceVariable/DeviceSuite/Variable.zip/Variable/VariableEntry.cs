﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CxDeviceSuite.Variable
{
    public struct VariableEntry
    {
        public int UpdateId { get; set; }
        public int Id { get; set; }
        public Object Value { get; set; }
        public int Source { get; set; }
    }
}
