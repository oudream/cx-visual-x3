﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CxDeviceSuite
{

    public class VariableDouble : VariableBase
    {
        public double Value { get; private set; }

        protected override Type GetValueType() => typeof(double);
        public override object GetValueObject() => Value;

        public override void UpdateValue(object newValue)
        {
            if (newValue is double doubleValue)
            {
                Value = doubleValue;
                RecordChange(); // 记录变化时间
            }
        }
    }
}
