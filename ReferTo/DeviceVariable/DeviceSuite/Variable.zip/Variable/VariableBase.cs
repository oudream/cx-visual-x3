﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CxDeviceSuite
{
    // 变量基类
    public abstract class VariableBase
    {
        public int Id { get; set; }
        public int Gid { get; set; }
        public string Code { get; set; }
        public string URI { get; set; }
        public string Name { get; set; }
        public Type ValueType
        {
            get
            {
                return GetValueType(); // 存储类型
            } // 存储类型
        }

        public string ValidRange { get; set; } // 有效范围
        public int MaxLength { get; set; } // 最大长度

        public string VariableType { get; set; } // 变量类型（功能、业务）

        public DateTime LastChangeTime { get; private set; } // 最近一次值变化时间
        public int ChangeSource { get; set; } // 变化源


        protected abstract Type GetValueType();
        public abstract object GetValueObject();
        public abstract void UpdateValue(object newValue);

        protected void RecordChange()
        {
            LastChangeTime = DateTime.UtcNow; // 记录变化时间（UTC时间）
        }
    }

    /**
    VariableBase variable;
    switch (entry.Value)
    {
        case int intValue:
            variable = new VariableInt { Id = entry.Id, Value = intValue };
            break;
        case double doubleValue:
            variable = new VariableDouble { Id = entry.Id, Value = doubleValue };
            break;
        case string stringValue:
            variable = new VariableString { Id = entry.Id, Value = stringValue };
            break;
        default:
            throw new InvalidOperationException("Unsupported variable type");
    }
 */
}
