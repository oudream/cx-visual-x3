﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CxDeviceSuite.Variable
{
    // 字符串类型的变量
    public class VariableString : VariableBase
    {
        public string Value { get; private set; }

        protected override Type GetValueType() => typeof(string);
        public override object GetValueObject() => Value;

        public override void UpdateValue(object newValue)
        {
            if (newValue is string stringValue)
            {
                Value = stringValue;
                RecordChange(); // 记录变化时间
            }
        }
    }
}
