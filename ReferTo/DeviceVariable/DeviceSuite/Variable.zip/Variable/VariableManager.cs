﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace CxDeviceSuite.Variable
{
    public class VariableManager
    {
        private Dictionary<int, VariableBase> _variables = new Dictionary<int, VariableBase>();

        private int _updateId;
        //private ConcurrentStack<VariableEntry> _updateStack;

        private readonly object _listLock = new object();
        private List<VariableEntry> _updateList = new List<VariableEntry>();

        private ManualResetEvent _updateSignal = new ManualResetEvent(false);
        public event Action<int, List<VariableEntry>> OnVariableChanged;

        public VariableManager()
        {
            //_updateStack = new ConcurrentStack<VariableEntry>();
            new Thread(() =>
            {
                try
                {
                    while (true)
                    {
                        // 等待一小段时间或直到收到更新信号
                        //_updateSignal.WaitOne(); // 等待更新信号
                        _updateSignal.WaitOne(TimeSpan.FromMilliseconds(100));

                        // 处理所有积累的更新
                        //if (_updateStack.IsEmpty)
                        //{
                        //    _updateSignal.Reset();
                        //    continue;
                        //}

                        // 
                        ProcessUpdates();

                        _updateSignal.Reset();
                    }
                }
                catch (Exception ex)
                {
                    // 记录异常
                    LogException(ex);
                }

            })
            { IsBackground = true }.Start();
        }

        private void LogException(Exception ex)
        {
            // 这里只是一个示例，具体实现取决于您的日志系统
            Console.WriteLine($"Exception in VariableManager thread: {ex.Message}");
            // 如果有更复杂的日志系统，可以这样：
            // Logger.Error(ex, "Exception in VariableManager thread");
        }

        public void RegisterVariable(VariableBase variable)
        {
            if (!_variables.ContainsKey(variable.Id))
            {
                _variables[variable.Id] = variable;
            }
        }

        // Push 一个变量
        public void PushInt(int id, int value, int source)
        {
            Interlocked.Increment(ref _updateId);
            var entry = new VariableEntry { UpdateId = _updateId, Id = id, Value = value, Source = source };
            lock (_listLock)
            {
                _updateList.Add(entry);
            }
            _updateSignal.Set(); // 触发信号通知更新
        }
        public void PushDouble(int id, double value, int source)
        {
            Interlocked.Increment(ref _updateId);
            var entry = new VariableEntry { UpdateId = _updateId, Id = id, Value = value, Source = source };
            lock (_listLock)
            {
                _updateList.Add(entry);
            }
            _updateSignal.Set(); // 触发信号通知更新
        }
        public void PushString(int id, string value, int source)
        {
            Interlocked.Increment(ref _updateId);
            var entry = new VariableEntry { UpdateId = _updateId, Id = id, Value = value, Source = source };
            lock (_listLock)
            {
                _updateList.Add(entry);
            }
            _updateSignal.Set(); // 触发信号通知更新
        }

        // Push 多个变量
        public void PushInts(params (int Id, int Value, int Source)[] ps)
        {
            //var lv = ps.Select(e => new VariableEntry { Id = e.Id, Value = e.Value, Source = e.Source });
            lock (_listLock)
            {
                foreach (var p in ps)
                {
                    Interlocked.Increment(ref _updateId);
                    var entry = new VariableEntry { UpdateId = _updateId, Id = p.Id, Value = p.Value, Source = p.Source };
                    _updateList.Add(entry);
                }
            }
            _updateSignal.Set(); // 只需触发一次信号
        }
        public void PushDoubles(params (int Id, double Value, int Source)[] ps)
        {
            //var lv = ps.Select(e => new VariableEntry { Id = e.Id, Value = e.Value, Source = e.Source });
            lock (_listLock)
            {
                foreach (var p in ps)
                {
                    Interlocked.Increment(ref _updateId);
                    var entry = new VariableEntry { UpdateId = _updateId, Id = p.Id, Value = p.Value, Source = p.Source };
                    _updateList.Add(entry);
                }
            }
            _updateSignal.Set(); // 只需触发一次信号
        }
        public void PushStrings(params (int Id, string Value, int Source)[] ps)
        {
            //var lv = ps.Select(e => new VariableEntry { Id = e.Id, Value = e.Value, Source = e.Source });
            lock (_listLock)
            {
                foreach (var p in ps)
                {
                    Interlocked.Increment(ref _updateId);
                    var entry = new VariableEntry { UpdateId = _updateId, Id = p.Id, Value = p.Value, Source = p.Source };
                    _updateList.Add(entry);
                }
            }
            _updateSignal.Set(); // 只需触发一次信号
        }
        private void ProcessUpdates()
        {
            List<VariableEntry> nvList;
            lock (_listLock)
            {
                nvList = new List<VariableEntry>(_updateList);
                _updateList.Clear();
            }
            if (nvList.Count <= 0)
            {
                return;
            }
            //List<VariableEntry> nvList = _updateStack.ToList();
            //_updateStack.Clear();
            //while (_updateStack.TryPop(out var logEntry))
            //{
            //    nvList.Add(logEntry);
            //}
            //nvList.Sort((a, b) => a.Id.CompareTo(b.Id));

            List<VariableEntry> changedEntries = new List<VariableEntry>();
            foreach (var nv in nvList)
            {
                var oldVariable = _variables[nv.Id];
                if (oldVariable != null)
                {
                    var oldValue = oldVariable.GetValueObject();
                    if (!Equals(oldValue, nv.Value))
                    {
                        oldVariable.UpdateValue(nv.Value);
                        changedEntries.Add(nv); // 收集发生变化的条目
                    }
                }
            }

            if (changedEntries.Any())
            {
                OnVariableChanged?.Invoke(changedEntries.Count, changedEntries); // 一次性通知所有变化
            }
        }

    }

    /**  事件处理程序的线程安全性
     * 
// 操作共享资源 
private readonly object _lockObject = new object();

private void OnVariableChangedHandler(int id, VariableEntry entry)
{
        lock (_lockObject)
        {
            // 安全地操作共享资源
        }
}

// Windows Forms 示例
private void OnVariableChangedHandler(int id, VariableEntry entry)
{
        if (this.InvokeRequired)
        {
            this.Invoke(new Action(() => UpdateUI(id, entry)));
        }
        else
        {
            UpdateUI(id, entry);
        }
}

private void UpdateUI(int id, VariableEntry entry)
{
        // 更新 UI 的代码
}

     */

}
